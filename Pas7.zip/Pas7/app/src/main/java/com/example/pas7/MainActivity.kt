package com.example.pas7

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        val activity = findViewById<ConstraintLayout>(R.id.activity)
        return when (item.itemId) {
            R.id.action1 -> {
                activity.background = getDrawable(R.color.redColor)
                true
            }

            R.id.action2 -> {
                activity.background = getDrawable(R.color.blueColor)
                true
            }

            R.id.action3 -> {
                activity.background = getDrawable(R.color.greenColor)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}