package com.example.pasp8



import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val button = findViewById<Button>(R.id.button)
        val textView = findViewById<TextView>(R.id.textView)
        val imageView = findViewById<ImageView>(R.id.imageView)

        val viewClickListener =
            View.OnClickListener { v -> showPopupMenu(v) }

        button.setOnClickListener(viewClickListener)
        textView.setOnClickListener(viewClickListener)
        imageView.setOnClickListener(viewClickListener)
    }

    private fun showPopupMenu(v: View?) {
        val popupMenu = PopupMenu(this, v)
        popupMenu.inflate(R.menu.menu_main)
        popupMenu.setOnMenuItemClickListener {
            when (it.itemId) {
                R.id.menu1 -> {
                    Toast.makeText(
                        applicationContext,
                        "Вы выбрали PopupMenu 1",
                        Toast.LENGTH_SHORT
                    ).show()
                    true
                }

                R.id.menu2 -> {
                    Toast.makeText(
                        applicationContext,
                        "Вы выбрали PopupMenu 2",
                        Toast.LENGTH_SHORT
                    ).show()
                    true
                }

                R.id.menu3 -> {
                    Toast.makeText(
                        applicationContext,
                        "Вы выбрали PopupMenu 3",
                        Toast.LENGTH_SHORT
                    ).show()
                    true
                }

                else -> false
            }
        }
        if (Build.VERSION.SDK_INT >=Build.VERSION_CODES.Q){
            popupMenu.setForceShowIcon(true)
        }
        v?.setOnClickListener{
            popupMenu.show()
        }
    }
}