package com.example.pasp5

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    private var counter: Int = 0
    private var count: Int = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val buttonHi = findViewById<Button>(R.id.button1ID)
        val buttonCount = findViewById<Button>(R.id.button2ID)
        val textView = findViewById<TextView>(R.id.textViewID)
        val img = findViewById<ImageView>(R.id.imageID)

        buttonHi.setOnClickListener{
            textView.text = getString(R.string.text3)
        }
        buttonCount.setOnClickListener{
            counter++
            textView.text = getString(R.string.text4, counter)
        }
        img.setOnClickListener{
            count++
            textView.text = getString(R.string.text5, count)
        }
    }
}